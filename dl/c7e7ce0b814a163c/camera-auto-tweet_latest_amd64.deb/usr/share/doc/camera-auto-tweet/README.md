# Camera Auto Tweet

One static Go binary per camera. It fetches a frame from the camera, normalises
it to 16:9, and posts it to X with a comment written for that slot at a fixed
time of day. Runs on a Raspberry Pi (arm64) or an x86 LXC (amd64).

## Build

```sh
make            # vet, test, build ./camera-auto-tweet
make cross      # dist/camera-auto-tweet-linux-{arm64,amd64}
make deb        # dist/camera-auto-tweet_<version>_{amd64,arm64}.deb
```

Go 1.27, `CGO_ENABLED=0`, timezone database embedded. At runtime the binary
needs nothing; ffmpeg is used only for RTSP capture.

The Debian version comes from `git describe --tags --always --dirty`, falling
back to `0.0.0~dev`. The leading `v` is dropped, `-alpha`/`-beta`/`-rc` becomes
`~alpha`/`~beta`/`~rc` so a pre-release sorts before its release, `-dirty`
becomes `+dirty`, and remaining hyphens become `+`:
`v1.2.0-beta-3-gabc123-dirty` → `1.2.0~beta+3+gabc123+dirty`. Override with
`make deb DEB_VERSION=1.2.3`.

## Releasing

Every published build gets a new beta number — `v0.1.0-beta2`, `v0.1.0-beta3` —
never a moved tag. Reusing one tag meant every package claimed the same version
and apt called the newest build "already the newest version". The package
version is `<tag>+<commit count>` (`0.1.0~beta2+59`), so rebuilds within a beta
still sort in order.

```sh
git tag -a v0.1.0-beta<N> -m "0.1.0-beta<N>"
make deb                        # dist/*.deb, version from the tag
python3 tools/release.py v0.1.0-beta<N>   # upload + SHA256SUMS
```

## Install

At a customer site, follow [docs/INSTALL.md](docs/INSTALL.md) — the operational
checklist, including what "working" looks like before you leave.

```sh
sudo apt install ./dist/camera-auto-tweet_<version>_amd64.deb
```

`postinst` creates the `camt` system user, then plants
`/etc/camera-auto-tweet/config.yaml` — mode 0600, owned by `camt`, bound to
`0.0.0.0:8080` with a generated bcrypt password. The password is printed by
dpkg and also written to `/etc/camera-auto-tweet/gui-password` (root, 0600).
The unit is enabled and started. Open `http://<host>:8080` and finish setup in
the browser.

The package installs `/usr/bin/camera-auto-tweet`, the unit at
`/lib/systemd/system/camera-auto-tweet.service` (runs as `camt`, config from
`/etc`, data in `/var/lib/camera-auto-tweet`), and the example config as a
conffile. `config.yaml` itself is not shipped. Do not copy the example over it:
that restores the placeholder camera URL and drops the generated password.
`Depends: ffmpeg, adduser`.

`deploy/camera-auto-tweet.service` is the unit for a hand-rolled `/opt` install:
binary and config in `/opt/camera-auto-tweet`, data in
`/opt/camera-auto-tweet/data`.

## Configure

In the browser. `serve` writes a starter `config.yaml` (0600) when none exists
and starts the GUI regardless, so a new box boots into its setup screen. Set the
site name and camera URL on the Camera page; connect the X account on the
Account page (consumer key and secret, then OAuth 1.0a PIN flow with a QR code).
Until a camera URL is set the box is in *setup* state: the GUI runs, nothing is
captured or posted, and a slot that comes due is skipped with a log line rather
than recorded as a failure.

Or in YAML, for scripted installs. Copy `config.example.yaml` to `config.yaml`,
`chmod 600`, and replace the placeholder host — the example ships a fake
`192.168.1.253` URL that would otherwise count as configured.
`config.example.yaml` documents every option with the code's defaults.

## Capture modes

`camera.mode: jpeg` (default) is one GET to `camera.snapshot_url`, fetched
verbatim with credentials in the query string or as URL userinfo. It is the
cheapest path and needs no external program.

`camera.mode: rtsp` runs ffmpeg once per capture to take a single frame from
`camera.rtsp_url` (`rtsp_transport: tcp` by default; UDP starts faster and drops
frames). It costs an H.264 decode and a subprocess, and exists for cameras whose
snapshot endpoint serves only the substream while the main stream is on RTSP.

Both paths validate the bytes rather than the status: a JPEG SOI marker, at
least 1 KB, an EOI marker, and decodable dimensions. These cameras answer
`200 OK` with a login page or a plain-text complaint. Each capture retries up to
`camera.attempts` (default 3, 15 s timeout) with backoff; a 401/403 is not
retried.

## Image

The frame is cropped (default) or letterboxed (`fit: pad`) to 16:9, scaled to
`camera.width` (default 1200, so 1200×675), and re-encoded as JPEG q85. It never
upscales: a 640×480 source becomes 640×360. Measured: 1920×1080 → 1200×675.

## Slots

A slot is a time of day plus the comment that goes with it. The morning slot and
the evening slot are separate entries with their own prose, not one template with
conditionals inside it.

```yaml
schedule:
  slots:
    - time: "07:00"
      text: "{{.DateJP}}の朝{{.Hour12}}時です。おはようございます"
    - time: "18:30"
      text: "{{.DateJP}}の夜{{.Hour12}}時です。おやすみなさい"
```

Placeholders: `{{.Site}}`, `{{.Date}}`, `{{.DateJP}}`, `{{.Time}}`, `{{.Hour}}`
(24-hour), `{{.Hour12}}` (12-hour, so 18:30 renders 6), `{{.WeekdayJP}}`. A slot
may carry its own `alt_text`, otherwise `post.alt_text` is used. Comments are
limited to 280 weighted units, CJK and kana counting 2; the Posting page shows
each comment's count and refuses to save one that is over.

## At most once

A slot never posts twice. `runs.db` enforces that, rather than trusting the
process to stay alive:

- each slot is a row keyed by local date and time, e.g. `2026-11-03/07:00`;
- the row is written as `posting` before the upload leaves the box;
- a crash after that point leaves the row ambiguous, so on the next start it
  becomes `unknown` and is never retried automatically;
- a failure before anything reached X (camera unreachable, upload rejected) is
  `failed`, which is safe to retry;
- an X duplicate rejection counts as `posted`, since the post is evidently live.

A missing post is a smudge; a duplicate on a customer's public feed is an
incident, so the ambiguity resolves downward.

The Logs page lists every run and offers *Post anyway*. It works on a `failed`
row only; on an `unknown` row it refuses, because that post may already be live
and only a person can decide.

## Alerts

Failures go to `notify.webhook_url`. The payload carries the same text under
`content`, `text` and `message` (plus `title`), which covers Discord, Slack and
ntfy without per-service configuration. An empty URL disables alerts.

An alert is sent for a failed slot, a camera 401/403, a camera unreachable for
three consecutive failed slots, and X rejecting the credentials; the first
successful post after any of these sends a recovery, which also clears the
suppression. Repeats of one kind are suppressed for `notify.cooldown_minutes`
(default 30), and the last-sent times live in `runs.db`, so a crash loop cannot
re-alert on every boot.

```sh
camera-auto-tweet notify --config config.yaml   # send a test alert
```

## CLI

```sh
serve     --config config.yaml [--data DIR] [--log-file F] [--gui off|ADDR]
validate  --config config.yaml
capture   --config config.yaml [--out frame.jpg] [--url URL]
post      --config config.yaml [--dry-run] [--data DIR]
runs      --config config.yaml [--limit N]
notify    --config config.yaml
whoami    --config config.yaml
connect   --config config.yaml [--start | --pin CODE]
passwd    <password>
version
```

`post` creates a manual run and refuses without X credentials; `--dry-run`
captures, normalises and renders, printing the weighted count, then stops.
`connect` is the PIN flow from a terminal, for a box with no browser.

## Testing without credentials

```sh
go run ./tools/fakecamera -addr 127.0.0.1:8099 -w 1920 -h 1080 &
go run ./tools/fakex -addr 127.0.0.1:8096 -log /tmp/fakex.log &
CAT_X_BASE_URL=http://127.0.0.1:8096 ./camera-auto-tweet serve --config config.yaml
```

`CAT_X_BASE_URL` redirects every X call, posting and onboarding, to the mock,
which logs one JSON line per request so you can count what left the box.
`fakecamera -mode html|401|slow` reproduces the failure modes these cameras
produce.

## Tests

`go test ./...`. Covers the OAuth 1.0a signature against the RFC 5849 test
vector, JPEG rejection of HTML and truncated bodies, credential redaction, 16:9
crop and pad geometry, the no-upscale rule, and weighted character counting.
