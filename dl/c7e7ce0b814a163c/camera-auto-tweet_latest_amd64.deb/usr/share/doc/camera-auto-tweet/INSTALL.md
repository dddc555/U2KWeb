# Installing at a customer site

Fifteen minutes, one box, one camera. Everything below happens in the GUI except
the install itself.

## 0. Before you leave

- Build and tag: `make deb` produces `dist/camera-auto-tweet_<version>_<arch>.deb`.
- Note the checksum from `dist/SHA256SUMS`. You will compare it on site.
- Know the camera's snapshot URL **with credentials**, and confirm it works from
  your laptop on the same network before you promise anything.

## 1. Install

```sh
wget -O cat.deb    '<release asset url>'     # see the release page
wget -O SHA256SUMS '<release asset url>'
sha256sum -c SHA256SUMS --ignore-missing     # must print: cat.deb: OK

apt install ./cat.deb                        # not dpkg -i: apt resolves ordering
```

The service is enabled and started by the package. It prints the GUI address and
a generated password:

```
camera-auto-tweet: Web GUI is listening on port 8080.
  password: XXXXXXXXXXXX
  (also written to /etc/camera-auto-tweet/gui-password)
```

If the password is lost: `sudo cat /etc/camera-auto-tweet/gui-password`, or
regenerate with `camera-auto-tweet passwd <new>` and paste the hash into
`web.password_hash`.

## 2. First look

Open `http://<box-ip>:8080`. The dashboard must say **"Not set up yet"**. If it
does not, the config was planted from a previous install — stop and investigate
before a scheduled post fires.

## 3. Camera page

- **Site name** — appears in every post as `{{.Site}}`. Use what the customer
  calls the place ("山田様 正面玄関"), not a hostname.
- **Snapshot source** — paste the camera URL including credentials. They may be
  in the query string (`?username=…&password=…`) or in the path
  (`/user=…&password=…&channel=1&stream=0.sdp?`) on RTSP firmware.
- **Press "Test capture"**. You need `1200×675` (or the camera's aspect after
  crop) and a picture you can recognise. If the endpoint returns a substream
  (720×480 is a common sign), switch to **RTSP** and install ffmpeg:
  `apt install ffmpeg`.
- **Keep snapshots** stays at 100.

## 4. Posting page

- Add a slot per daily time. Each slot has its own comment and alt text.
- Tick the days. A slot on an unticked day is skipped, not caught up.
- **Timezone** — check it. Default `Asia/Tokyo`; a JST box and this setting
  agreeing is not a coincidence you should rely on at another site.

## 5. Account page

1. Paste the consumer key and secret from your developer app. One app serves all
   customers; each customer authorises their own account.
2. **Connect X account** → a QR code and a link appear.
3. The customer (or you, signed in as them) opens it on a phone and taps
   **Authorize**. X shows a ~7 digit PIN.
4. Type the PIN. The header now shows `@handle` on every page.

The request token expires after 30 minutes — start and finish the flow in one
sitting or start it again. It does not need both of you in the same room, but it
does need to be within that window.

**The handle in the header is the account that will post.** If it is wrong,
re-run the flow — the old token is replaced, not kept.

## 6. Prove it

Press **Post now** on one slot. Then check all four:

- the post exists on X, authored by the handle in the header;
- the image is the camera's current view, 1200×675;
- the alt text names the site and time;
- **Logs** shows the slot `posted` with a link to the post.

A working install with no live post is not a verified install.

## 7. Leaving it

```sh
systemctl status camera-auto-tweet     # enabled, active
camera-auto-tweet runs                 # times in site time, nothing unexpected
```

Set the alert target before you leave — **outbound only**, no inbound port and no
tunnel, so a VPN-only site can still send one. Either a webhook (Discord, Slack,
ntfy) or a Telegram bot token plus chat id, in `notify:`. Then:

```sh
camera-auto-tweet notify --config /etc/camera-auto-tweet/config.yaml
```

That sends one test message; if it does not arrive, nothing else will. The daily
heartbeat (`notify.heartbeat: daily`, 09:00 site time) is the dead-man's switch:
no message today means the box is off, offline, or wedged.

## Upgrading

```sh
apt install ./new.deb
```

Versions carry the commit count (`0.1.0~beta1+58`), so a newer build always
installs over an older one and the service restarts on the new binary by itself.
Removing the old package first is not necessary and leaves the box in `rc` state.

Config and data in `/etc/camera-auto-tweet` and `/var/lib/camera-auto-tweet` are
preserved, ownership and permissions included. Do not delete the config to
upgrade. A restart during a post leaves that slot `unknown`; close it from Logs.

## If it will not start

```sh
journalctl -u camera-auto-tweet -n 40 --no-pager
```

| Message | Cause |
|---|---|
| `web.password_hash must be a bcrypt hash` | hash mangled by hand editing; regenerate with `camera-auto-tweet passwd` |
| `web.addr "0.0.0.0:8080" is not loopback` | binding to the LAN without a password hash |
| `camera.snapshot_url is required` | still in setup state; finish the Camera page |
| `address already in use` | another instance on the port (often a leftover manual `serve`) |

Uninstalling: `apt remove camera-auto-tweet` keeps config and snapshots;
`apt purge` removes both `/etc/camera-auto-tweet` and `/var/lib/camera-auto-tweet` — the
config, the run history and every snapshot. Only purge a box you are retiring or
resetting deliberately: with no history, a slot inside the catch-up window can no
longer be told apart from one that has not run.
